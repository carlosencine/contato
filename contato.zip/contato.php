<?php
/**
 * classe para envio de emails usando o phpmailer
 * Data de Criação: 11/02/2014
 * @author EZIO
 */
require 'phpmailer/PHPMailerAutoload.php';

class contato extends PHPMailer {
    public $nome,
           $email,
           $assunto,
           $mensagem,
           $validacao;//segunda validação para o formulário
    
    
    function __construct()
    {
        //construtor para gerar o formulário html
        echo "<form action=\"\" name=\"contato\" id=\"contato\" method=\"post\" onsubmit=\"return validar(this);\">
            <h2>Contato</h2>
            <input type=\"text\" name=\"nome\" size=\"50\" placeholder=\"Nome\"/><br>
            <input type=\"text\" name=\"email\" size=\"50\" placeholder=\"E-mail\"/><br>
            <input type=\"text\" name=\"assunto\" size=\"50\" placeholder=\"assunto\"/><br>
            <textarea name=\"mensagem\" cols=\"39\" rows=\"10\" placeholder=\"Mensagem\"></textarea><br>
            <input type=\"text\" name=\"validacao\" placeholder=\"A raiz quadrada de 49 é?\"><br>
            <input type=\"submit\" name=\"enviar\" value=\"Enviar\">
            </form>";
    }
    
    function validaform()
    {
        //função jvascript para validação do formulárrio
        echo "<script type=\"text/javascript\">
	function validar(contato){
		if(contato.nome.value == ''){
			alert(\"preeencha o campo Nome.\");
			return false;
		}
		if(contato.email.value == ''){
			alert(\"Preeencha o campo E-mail\");
			return false;
		}
		if(contato.assunto.value == ''){
			alert(\"Preencha o campo Assunto\");
			return false;
		}
		if(contato.msg.value == ''){
			alert(\"Preencha o campo com uma mensagem\");
			return false;
		}
		return true;
	}
</script>";
       
    }
    
    function getDados()
    {
        //obtem os dados do formulário via POST
        $this->nome = strip_tags($_POST['nome']);
        $this->email = strip_tags($_POST['email']);
        $this->assunto = strip_tags($_POST['assunto']);
        $this->mensagem = strip_tags($_POST['mensagem']);
        $this->validacao = strip_tags($_POST['validacao']);
    }
    
    function validar()
    {
        if($this->validacao != 7)
        {
            echo "Mensagem não pode ser enviada";
            exit();
        }
    }
            
    function enviaEmail()
    {
        $this->isSMTP();
        $this->SMTPAuth = true;//informa se o email será utenticado
        $this->Host = "";//servidor
        $this->Port = 587;//porta
        $this->Username = "";//usuario
        $this->Password = "";//senha
        $this->setFrom('', 'nome do site');//para quem será enviado 1)endereço 2)cabeçalho da mensagem
        $this->Subject = "Contato enviado atrevés do site";//assunto
        
        $body = "Nome: {$this->nome}<br>
                 E-mail: {$this->email}<br>
                 Assunto:{$this->assunto}<br>
                 Mensagem: {$this->mensagem}<br>";
        $this->msgHTML($body);//cabeçalho da mensagem
        $this->addAddress("carlos_alexandre88@hotmail.com");//redireciona para outro endereço
        
        if(!$this->send())
        {
            echo "<script type=\"text\javascript\">";
            echo "alert(\"Mensagem não enviada\");";
            echo "</script>";
        } else {
            echo "Mensagem enviada com sucesso";
            
        }
        
    }
}

?>
